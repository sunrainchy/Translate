/*
* Copyright (C) 2008  Zhang Huan (zh1262@yahoo.cn)
*
* 2011-07-10
*
* Protocol: GPL v2
*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<error.h>

#include<curl/curl.h>
#include<curl/easy.h>

#include<iconv.h>

#define BUFFER 4096

char result[BUFFER];
char src[24]="en";
char dest[24]="zh_CN";
short  translate_flag=0;

int get_content(char *html_content)
{
  char *ss_start = NULL;
  char *se_end = NULL;

  char *ss = "Color='#fff'\">";
  char *se = "</span>";

  ss_start = strstr(html_content, ss);
  
  if(ss_start != NULL&&translate_flag==0)
  {
  	se_end = strstr(ss_start, se);
	ss_start += strlen(ss);
	strncat(result, ss_start, se_end - ss_start); 
	translate_flag++;
  	return 0;
  }

  return -1;
}

size_t write_data(void *ptr,size_t size,size_t nmemb,void *stream)
{
  FILE *fp;
  int rs;
/* 
  char * test;
  test=(char*)ptr;
  printf("\n%s\n",test);
*/
  get_content((char *)ptr);
  fp=fopen("/dev/null","w");
  rs=fwrite(ptr,size,nmemb,fp);
  fclose(fp);

  return rs;
}

int URLEncode(const char* str, const int strSize, char* result, const int resultSize) 
{
	int i;
	int j = 0;
	char ch;

	if ((str == NULL) || (result == NULL) || (strSize <= 0) || (resultSize <= 0)) {
		return 0;
	}

	for (i=0; (i<strSize) && (j<resultSize); i++) {
		ch = str[i];
		if ((ch >= 'A') && (ch <= 'Z')) {
			result[j++] = ch;
		} else if ((ch >= 'a') && (ch <= 'z')) {
			result[j++] = ch;
		} else if ((ch >= '0') && (ch <= '9')) {
			result[j++] = ch;
		} else if(ch == ' ' || ch == '\n' || ch == '\r'|| ch == '\t'){
			result[j++] = '+';
		} else {
			if (j + 3 < resultSize) {
				sprintf(result+j, "%%%02X", (unsigned char)ch);
				j += 3;
			} else {
				return 0;
			}
		}
	}

	result[j] = '\0';
	return j;
} 

int translate_engine(char *inputText)
{
  char urlstr[BUFFER];
  char langpair[256];
  char engineUrl[256];
  CURL *curl;
  
  memset(urlstr, 0, BUFFER);
	
  int inputTextLen = sizeof(char) * 3 * strlen(inputText);
  char *inputText_encoded = malloc(inputTextLen);
  
  sprintf(langpair, "%s|%s", src, dest);
  sprintf(engineUrl, "%s", "http://translate.google.cn/translate_t");

  URLEncode(inputText, strlen(inputText), inputText_encoded, inputTextLen + 2);
  sprintf(urlstr, "%s?text=%s&langpair=%s", engineUrl, inputText_encoded, langpair);

//  fprintf(stdout, "urlstr: %s\n", urlstr);

  curl_global_init (CURL_GLOBAL_ALL);
  curl = curl_easy_init ();
#ifdef _DEBUG
  curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
#endif
  curl_easy_setopt (curl, CURLOPT_URL, urlstr);
  curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, write_data);	
  curl_easy_perform (curl);
  curl_easy_cleanup (curl);

  return 0;
}

int code_convert(char *from_charset,char *to_charset,char *inbuf,int inlen,char *outbuf,int outlen)
{
iconv_t cd;
int rc;
char **pin = &inbuf;
char **pout = &outbuf;

cd = iconv_open(to_charset,from_charset);
if (cd==0) return -1;
memset(outbuf,0,outlen);
if (iconv(cd,pin,&inlen,pout,&outlen)==-1) return -1;
iconv_close(cd);
return 0;
}

int main(int argc,char *argv[])
{
  char *result_converted=malloc(BUFFER);
  switch (argc){
   case 2:  break;
   case 3:  
    if(!strcmp(argv[1],"zh_CN"))
    {
       strcpy(dest,"en");
       strcpy(src,argv[1]);
    }
    break;
   default: printf("help:  Gtrans [input language 'en'or'zh_CN'--default 'en'] ['string']\n");
   return 0;
  }
  translate_engine(argv[argc-1]);
  code_convert("gb2312","utf-8",result,strlen(result),result_converted,BUFFER);
  printf("translated result: \n%s\n",result_converted);
  return 0;
}
